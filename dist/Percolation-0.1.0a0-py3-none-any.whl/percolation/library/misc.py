import time


class OneIndexedList(list):
    def __getitem__(self, i):
        return super().__getitem__(i - 1)

    def __setitem__(self, i, value):
        return super().__setitem__(i - 1, value)


def timeit(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()

        print('Execution Time ({0}): {1:.5f} seconds'.format(
            func.__name__, end_time - start_time))

        return result

    return wrapper
